if [ ! -d  "$1" ]; then
	#create the folder
	mkdir -p "$1"
fi

#allow access to video group
chgrp video  "$1"

#give video group write permission
chmod +775 "$1"

# new file create with video group
chmod g+s  "$1"

# give write access to video group
setfacl -d -m g::rwX "$1"

