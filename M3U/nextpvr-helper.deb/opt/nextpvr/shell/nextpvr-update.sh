
curl "http://nextpvr.com/beta/linux/NPVR.zip" -o /tmp/NPVR.zip
unzip -u -o /tmp/NPVR.zip -d /opt/nextpvr/system
chmod 755 /opt/nextpvr/system/NextPVRServer.dll
find /opt/nextpvr/system/DeviceHost -name DeviceHostLinux -exec chmod 755 {} \;
